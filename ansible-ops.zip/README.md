# AnsibleOps – Centralized Ansible Framework

This is a starter framework for onboarding multiple applications into Ansible Tower.